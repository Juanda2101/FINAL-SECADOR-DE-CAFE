var indexSectionsWithContent =
{
  0: "c",
  1: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "files"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Archivos"
};

